VARSTROM product-page HTML demo
================================

Open index.html in a browser. It works offline and needs no server.

Included:
- Responsive product page inspired by the referenced VARSTROM layout.
- Product gallery using the supplied images.
- The edited speed-comparison graphic with 35 km/h in the speed row.
- Functional quantity selector, variant pills, cart drawer, search modal, login demo modal and accordions.
- Real login/payment/order processing is intentionally not connected.

Files:
- index.html
- assets/speed-comparison-35.png
- assets/installation-measurement.png
- assets/brake-levers-sensors.png
- assets/wheel-info.png
